/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import jdk.internal.org.objectweb.asm.util.Printer;

/**
 *
 * @author Daniel De La Hoz
 */
public class Ejercicios {
        public static int[] llenarVector(int[]vector) {
          for (int i = 0; i <vector.length ; i++) {
       vector[i]=(int)( Math.random()*9)+1;     
        }
  return vector;        
}
    public static int[] llenadoManual(int[]vector) {
       String aux;
        for (int i = 0; i < vector.length; i++) {
            do{
           aux=JOptionPane.showInputDialog(null,"digite elemento en la posicion["+i+"]");
        }while (aux==null);  
           vector[i]=Integer.parseInt(aux);
        }
        return vector;
    }
    public static void mostrarVector(int[] vector, JTextArea txtResultado) {
        for (int i = 0; i < vector.length; i++) {
            if (vector [i]!=0) {
                txtResultado.append(vector[i] + " ");
            }
        }
    }
    public static int[] Union(int v1[], int v2[]) {
        int pos = 0, cont = 0;
        int resultado[] = new int[v1.length+v2.length];
        resultado[0] = v1[0];
        for (int i = 1; i < v1.length; i++) {
            if (resultado[pos] != v1[i]) {
                pos = pos+1;
                resultado[pos] = v1[i];
                
            }
        }
        pos=pos+1;
        for (int i = 0; i < v2.length; i++) {
            for (int j = 0; j < resultado.length; j++) {
                if (v2[i] == resultado[j]) {
                    cont = cont + 1;
                }
            }
            if (cont == 0) {
               resultado[pos] = v2[i];
               pos++;
            } else {
                cont = 0;
            }

        }
        return resultado;
    }
    
     public static int[] Interseccion(int v1[], int v2[]) {
     int resultado[] = new int[v1.length+v2.length];
         for (int i = 0; i < v1.length; i++) {
             for (int j = 0; j < v2.length; j++) {
                 if (v1[i]==v2[j]) {
                     resultado[i]=v1[i];
                 }
             }
         }
         for (int i = 1; i < resultado.length; i++) {
             if (resultado[i-1]!=resultado[i]) {
                 resultado[i]=resultado[i];
             }else{
             resultado[i]=0;
             }
         }
         return resultado;
     }
    public static int []DifereciaA (int v1[],int v2[]) {
        int resultado[]=new int [v1.length+v2.length];int cont;
        for (int i = 0; i < v1.length; i++) {
             resultado[i]=v1[i];
             
         }
        for (int i = 0; i < resultado.length; i++) {
            for (int j = 0; j < v2.length; j++) {
                if (resultado[i]==v2[j]) {
                    resultado [i]=0;
                }
            }
        }
          for (int i = 1; i < resultado.length; i++) {
             if (resultado[i-1]==resultado[i]) {
                 resultado[i]=0;
             }
         }
        return resultado;
    }
    public static int[] InversoSimetrico(int v1[]) {
       int resultado[]=new int [v1.length];
       int vv[]=new int [5];
       v1=new int [10];
       v1[0]=2;
       v1[1]=8;
       v1[2]=5;
       v1[3]=5;
       v1[4]=8;
       v1[5]=2;
        for (int i = 0; i < v1.length; i++) {
            v1[i]=i+1;
            System.out.println("vector :");
        }for (int i = 0; i < v1.length; i++) {
            System.out.println(""+v1[i]);
        }
        System.out.println("vector simetrico:");
        for (int i = 0; i < v1.length; i++) {
            if(v1[i]==vv[i]){
                System.out.println("el vector se comprende como simetrico: "+v1[i]);
            }else{
                if(v1[i]!=vv[i]){
                    break;
                }
            }
        }
            return v1;
    }
    public static int[] Repeticion(int v1[]) {
        int resultado[]=new int [v1.length];
       for (int i = 0; i < v1.length; i++) {
        for ( int j = 0; j < v1.length; j++) {
            if (j!=i) 
                break;
                if (v1[i]==v1[j]) {
                    if (v1[i]==v1[i]) {
                        
              } resultado[i]= v1[j];
             }
            }
          }
            return resultado;
        } 
}