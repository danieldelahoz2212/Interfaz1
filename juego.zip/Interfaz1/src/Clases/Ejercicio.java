/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Hernan
 */
public class Ejercicio {

    public static void main(String[] args) {
        //1. Declarar el vector
        int v[];
        //2. Tamaño del vector
        v = new int[10];
        //todo de uno     
        int a[] = new int[5];
        //3. llenar vector, manual
       //v[0] = 2;
       // v[1] = 5;
       // v[2] = 7;
       // v[3] = 8;
       // v[4] = 3;
        //3,1. llenado semi-automatico
        for (int i = 0; i < v.length; i++) {
            v[i] = i + 1;
        }
        //4. Mostrar manual
        /*System.out.println(v[0]);
        System.out.println(v[1]);
        System.out.println(v[2]);
        System.out.println(v[3]);
        System.out.println(v[4]);*/
        //4,1. Mostrar automatico 
        System.out.println("vector Inicial");
        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i]+" ");
        }
        System.out.println("");
        //Ejercicio 1 imprima los elementos que sean pares
        System.out.println("Ejercicio 1. elementos pares");
        for (int i = 0; i < v.length; i++) {
            if (v[i]%2 ==0) {
                System.out.println(v[i] +" ");
            }
        }
        System.out.println("");

        //Ejercicio 2 imprima los  elementos que sean impares
        System.out.println("2 imprimir los elementos que sean impares");
        for (int i = 0; i < v.length; i++) {
            if (v[i]%2==1) {
                System.out.println(v[i] +" ");
            }
        }
        System.out.println("");

        
//Ejercicio 3 elemento pares comprendidos entre 4 y 7
        System.out.println("3 elementos pares comprendidos entre 4 y 7");
        for (int i = 0; i < v.length; i++) {
            if (v[i]%2==0 && (v[i]>=4 && v[i]<=7)) {
                System.out.println(v[i]+" ");
            }
        }
        System.out.println("");
       
        //Ejercicio 4 elemento con mayor valor
        int mayor;
        mayor = v[0];
        System.out.println("Ejercicio 4. Mayor Valor");
        for (int i = 0; i < v.length; i++) {
            if (v[i]>mayor) {
                mayor = v[i];
            }
        }
        System.out.println("El mayor valor es: "+ mayor);
        
//Ejercicio 5 elemento con menor valor
        int menor;
        menor = v[0];
        System.out.println("Ejercicio 5. Menor Valor");
        for (int i = 0; i < v.length; i++) {
            if (v[i] < menor) {
                menor = v[i];
            }
        }
        System.out.println("El menor valor es:" + menor);
        //Ejercicio 6 sumatoria de los elementos del vector
        int suma = 0;
       
        for (int i = 0; i < v.length; i++) {
            suma = suma + v[i];
        }
        System.out.println("sumatoria" +suma);

        //Ejercicio 7 imprimir los elementos alreves
        System.out.println("Numeros a la inversa ");
        for(int i =v.length-1;i >= 0;i--){
            System.out.println(v[i]+" ");
        }
        System.out.println(" ");
      
        //Ejercicio 8 saber cuando un numero es primo
        int n =57;
        int cont = 0;
        for (int i = 1; i <= n; i++) {
            if (n%i==0) {
                cont=cont + 1;
            }
            if (cont>2) {
                break;
            }
        }
        if (cont > 2) {
            System.out.println("El numero" + n + "no es primo");
        } else {
            System.out.println("El numero" + n + "es primo");
        }
    }

}