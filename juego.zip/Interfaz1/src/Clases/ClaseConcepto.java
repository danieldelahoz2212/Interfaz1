/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Daniel
 */
public class ClaseConcepto {
    public static void main(String[] args) {
        //holaMundo();
      // hola("Daniel",19);
        //suma(23,32);
       // resta(32,23);
       double sum;
       sum=suma2(suma2(suma2(10,2),35),32);
        System.out.println("la suma es: "+sum);
    }
    
    public static void holaMundo(){
        System.out.println("Hola Mundo");         
    }
    //paramentro
    public static void hola(String nombre, int edad) {
        System.out.println("Hola"+nombre+"tienes"+edad+"años de edad.");
    }
    public static void suma(int n1,int n2) {
        int sum;
       sum=n1+n2;
        System.out.println("la resta es: "+sum);
    }
     public static void resta(int n1,int n2) {
        int res;
       res=n1-n2;
        System.out.println("la suma es: "+res);
    }
public static double suma2(double n1, double n2){
double sum;
sum = n1 + n2;
return sum;
}

}