/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.Scanner;

/**
 *
 * @author Daniel De La Hoz
 */
public class Juego {
    public static void main(String[] args) {
        Scanner lea=new Scanner(System.in);
        int mun,n;
          n=(int) (Math.random() * 9) + 1;
        System.out.println("Introduce numero:\n");
        mun=lea.nextInt();
        while(mun!=n){
            if(mun>n)
                System.out.println("menor");
        else
                System.out.println("mayor");  
            
            System.out.println("Introduce numero: ");
            mun=lea.nextInt();
                }
        System.out.println("acertaste!!!");
    }
}
