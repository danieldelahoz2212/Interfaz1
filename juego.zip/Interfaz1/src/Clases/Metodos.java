/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 *
 * @author Daniel
 */
public class Metodos {
    public static int[] llenarVector(int[]vector) {
          for (int i = 0; i <vector.length ; i++) {
       vector[i]=(int)( Math.random()*9)+1;     
        }
  return vector;        
}
    public static int[] llenadoManual(int[]vector) {
       String aux;
        for (int i = 0; i < vector.length; i++) {
            do{
           aux=JOptionPane.showInputDialog(null,"digite elemento en la posicion["+i+"]");
        }while (aux==null);  
           vector[i]=Integer.parseInt(aux);
        }
        return vector;
    }
     public static void mostrarVector(int[] vector, JTextArea txtResultado){
        for (int i = 0; i < vector.length; i++) {
            txtResultado.append(vector[i]+" ");
        }
    }
     public static int[] burbuja(int[] arreglo){

      for(int i = 0; i < arreglo.length-1; i++){
        for(int j = 0;j < arreglo.length-1;j++){
          if(arreglo[j] > arreglo[j+1])
          {
            int tmp = arreglo[j+1];
            arreglo[j+1] = arreglo[j];
            arreglo[j] = tmp;
          }   
        } 
        
      }
      return arreglo;
    }
     
public static int[] seleccion(int A[]) {
          int i, j, menor, pos, tmp;
          for (i = 0; i < A.length - 1; i++) { // tomamos como menor el primero
                menor = A[i]; // de los elementos que quedan por ordenar
                pos = i; // y guardamos su posición
                for (j = i + 1; j < A.length; j++){ // buscamos en el resto
                      if (A[j] < menor) { // del array algún elemento
                          menor = A[j]; // menor que el actual
                          pos = j;
                      }
                }
                if (pos != i){ // si hay alguno menor se intercambia
                    tmp = A[i];
                    A[i] = A[pos];
                    A[pos] = tmp;
                }
          }
          return A;
}
public static int[] insercionDirecta(int A[]){
    int p, j;
    int aux;
    for (p = 1; p < A.length; p++){ // desde el segundo elemento hasta
              aux = A[p]; // el final, guardamos el elemento y
              j = p - 1; // empezamos a comprobar con el anterior
              while ((j >= 0) && (aux < A[j])){ // mientras queden posiciones y el
                                                                    // valor de aux sea menor que los
                             A[j + 1] = A[j];       // de la izquierda, se desplaza a
                             j--;                   // la derecha
              }
              A[j + 1] = aux; // colocamos aux en su sitio
    }
    return A;
}
public static void shell(int A[]){
   int salto, aux, i;
   boolean cambios;
   for(salto=A.length/2; salto!=0; salto/=2){
           cambios=true;
           while(cambios){ // Mientras se intercambie algún elemento
                       cambios=false;
                       for(i=salto; i< A.length; i++) // se da una pasada
                               if(A[i-salto]>A[i]){ // y si están desordenados
                                     aux=A[i]; // se reordenan
                                     A[i]=A[i-salto];
                                     A[i-salto]=aux;
                                     cambios=true; // y se marca como cambio.
                               }
                        }
            }
}
public static int[]ordenar (int vect[], int ind_izq, int ind_der)
{
  int i, j; /* variables indice del vector */
  int elem; /* contiene un elemento del vector */
  i = ind_izq;
  j = ind_der;
  elem = vect[(ind_izq+ind_der)/2];
  do
  {while (vect[i] < elem) //recorrido del vector hacia la derecha
    i++;
   while (elem < vect[j]) // recorrido del vector hacia la izquierda
    j--;
   if (i <= j) /* intercambiar */
   { int aux; /* variable auxiliar */
     aux = vect[i];
     vect[i] = vect[j];
     vect[j] = aux;
     i++;
     j--;
   }
  } while (i <= j);
  if (ind_izq < j) {ordenar (vect, ind_izq, j);} //Llamadas recursivas
  if (i < ind_der) {ordenar (vect, i, ind_der);}
        return null;

}
}
